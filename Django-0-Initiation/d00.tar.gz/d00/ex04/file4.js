function puffin()
{
	alert("Exercice réussi!");
}
